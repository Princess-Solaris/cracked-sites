<?php

/*
|-------------------------------
|	GENERAL SETTINGS
|-------------------------------
*/

$imSettings['general'] = array(
	'url' => 'http://csecrett.com/',
	'homepage_url' => 'http://csecrett.com/index.html',
	'icon' => 'http://csecrett.com/favImage.png',
	'version' => '14.0.6.2',
	'sitename' => 'Art Museum',
	'public_folder' => '',
	'salt' => 'i34nnuehkl1ja4zjig2z8kl6so3yty57ll',
);


$imSettings['admin'] = array(
	'icon' => 'admin/images/logo_lidnhcdq.png',
	'theme' => 'orange'
);
ImTopic::$captcha_code = "		<div class=\"x5captcha-wrap\">
			<label>Check word:</label><br />
			<input type=\"text\" class=\"imCpt\" name=\"imCpt\" maxlength=\"5\" />
		</div>
";

// End of file x5settings.php