<div class="text-center<?php if (isset($extraCssClass)) echo " " . $extraCssClass; ?>"><?php echo $message ?></div>
