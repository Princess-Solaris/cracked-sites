<?php

/*
|-------------------------------
|	GENERAL SETTINGS
|-------------------------------
*/

$imSettings['general'] = array(
	'url' => 'http://clairesecrett.com/',
	'homepage_url' => 'http://clairesecrett.com/index.html',
	'icon' => 'http://clairesecrett.com/favImage.png',
	'version' => '14.0.6.2',
	'sitename' => 'Nambia',
	'public_folder' => '',
	'salt' => 'nh7bh9owan56n0xcbx8yczx1yb22sk4l49inbvlzziqtuqqrq6bcq',
);


$imSettings['admin'] = array(
	'icon' => 'admin/images/logo_2bnj5c57.png',
	'theme' => 'orange'
);
ImTopic::$captcha_code = "		<div class=\"x5captcha-wrap\">
			<label>Check word:</label><br />
			<input type=\"text\" class=\"imCpt\" name=\"imCpt\" maxlength=\"5\" />
		</div>
";

// End of file x5settings.php